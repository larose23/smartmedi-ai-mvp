import DatabaseTest from '../components/DatabaseTest'

export default function DatabaseTestPage() {
  return (
    <main className="min-h-screen bg-gray-50">
      <DatabaseTest />
    </main>
  )
} 