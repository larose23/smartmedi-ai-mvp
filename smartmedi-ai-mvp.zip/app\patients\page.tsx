import PatientManagement from '../components/PatientManagement'

export default function PatientsPage() {
  return (
    <main className="min-h-screen bg-gray-50">
      <PatientManagement />
    </main>
  )
} 