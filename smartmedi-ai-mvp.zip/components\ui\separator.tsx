export default function Separator() {
  return <hr />;
} 