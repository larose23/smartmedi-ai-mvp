import EmergencyAlerts from '../components/EmergencyAlerts'

export default function AlertsPage() {
  return (
    <main className="min-h-screen bg-gray-50">
      <EmergencyAlerts />
    </main>
  )
} 