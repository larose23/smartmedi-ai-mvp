import StaffDashboard from '../components/StaffDashboard'

export default function StaffPage() {
  return (
    <main className="min-h-screen bg-gray-50">
      <StaffDashboard />
    </main>
  )
} 