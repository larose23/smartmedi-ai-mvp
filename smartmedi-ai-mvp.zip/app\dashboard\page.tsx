import Dashboard from './Dashboard';

export default function DashboardPage() {
  return <Dashboard />;
} 